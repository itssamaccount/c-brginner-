#include<iostream>

using namespace std;

int main(){

    char choice='y';
    while(choice=='y'||choice=='Y'){
        int a,b;
        cin>>a>>b;
        cout<<"Common Divisors:";
        for(int i=1;i<=a&&i<=b;i++){
            if(a%i==0&&b%i==0) cout<<i<<" ";
        }
        cout<<endl;
        cout<<"Continue? (y/n):";
        cin>>choice;
    }
    return 0;
}
