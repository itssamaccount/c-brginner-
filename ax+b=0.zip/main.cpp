#include<iostream>

using namespace std;

int main(){

    double a,b;
    cin>>a>>b;
    if(a==0&&b==0){
        cout<<"Invalid"<<endl;
    }else if(b==0){
        cout<<"Infinite solutions"<<endl;
    }else{
        double x=-b/a;
        cout<<"x="<<x<<endl;
    }
    return 0;
}
