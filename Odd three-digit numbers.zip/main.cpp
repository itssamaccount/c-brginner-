#include <iostream>

using namespace std;

int main(){
for(int i=101;i<=999;i+=2){
cout<<i<<endl;
}
return 0;
}

