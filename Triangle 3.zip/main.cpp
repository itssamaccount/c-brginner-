#include <iostream>

using namespace std;

int main()
{
    int n;
    cout<<"Enter number of rows: ";
    cin>>n;

    for (int i=n; i>=1; i--) {
        for (int sp=1; sp<=n-i; sp++) {
            cout<<" ";
        }
        for (int st=1; st<=i; st++) {
            cout<<"*";
        }
        cout<<endl;
    }
    return 0;
}
