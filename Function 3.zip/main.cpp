#include <iostream>

using namespace std;

int area(int length,int width){
    return length*width;
}

int perimeter(int length,int width){
    return 2*(length+width);
}

int main(){
    int l,w;
    cout<<"Enter length: ";
    cin>>l;
    cout<<"Enter width: ";
    cin>>w;

    cout<<"Area: "<<area(l,w)<<endl;
    cout<<"Perimeter: "<< perimeter(l,w)<<endl;

    return 0;
}
