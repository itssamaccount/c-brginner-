#include <iostream>

using namespace std;

int findSmallest(int a,int b,int c){
    return min(a,min(b,c));
}

int main(){

    int x,y,z;
    cout<<"Enter three numbers: ";
    cin>>x>>y>>z;
    cout<<"The smallest number is: "<<findSmallest(x,y,z)<<endl;

    return 0;
}

