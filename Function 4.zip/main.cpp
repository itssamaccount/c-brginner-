#include <iostream>

using namespace std;

void converttime(int totalSeconds){
    cout<<"Hours: "<< totalSeconds/3600<<endl;
    cout<<"Minutes: "<< (totalSeconds%3600)/60<< endl;
    cout<<"Seconds: "<< totalSeconds%60<<endl;
}

int main(){
    int s;
    cout<<"Enter total seconds: ";
    cin>>s;

    converttime(s);

    return 0;
}


