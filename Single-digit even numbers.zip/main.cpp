#include <iostream>

using namespace std;

int main()
{
 for(int i=2;i<10;i+=2){
    cout<<i<<endl;
 }
 return 0;
}
