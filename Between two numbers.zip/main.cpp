#include <iostream>

using namespace std;

int main(){
    int first,last;
    cout<<"Enter start number:";
    cin>>first;
    cout << "Enter end number:";
    cin >> last;
    for(int i=first; i<=last; i++){
        cout<<i<<" ";
    }
    return 0;
}

