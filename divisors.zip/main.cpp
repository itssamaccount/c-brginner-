#include<iostream>

using namespace std;

int main(){
    int n;
    cin>>n;
    int count=0,sum=0;
    cout<<"Divisors:";
    for(int i=1;i<=n;i++){
        if(n%i==0){
            cout<<i<<" ";
            count++;
            sum+=i;
        }
    }
    cout<<endl;
    cout<<"Count:"<<count<<endl;
    cout<<"Sum:"<<sum<<endl;
    return 0;
}
