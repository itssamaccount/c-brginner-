#include <iostream>

using namespace std;

int main()
{
    for(int i=11;i<100;i+=2){
            cout<<i<<endl;
    }
    return 0;
}
