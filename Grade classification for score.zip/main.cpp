#include<iostream>

using namespace std;

int main(){

    int score;
    cin>>score;
    if(score>=18)cout<<"A";
    else if(score>=15)cout<<"B";
    else if(score>=12)cout<<"C";
    else cout<<"F";
    return 0;

}
